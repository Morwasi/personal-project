package com.example.login;

import android.app.Activity;

public class PHPRequestClass {
    public void doRequest(Activity a){

    }

}
